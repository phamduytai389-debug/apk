package com.sewraywx.autotyping.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.sewraywx.autotyping.data.model.ControlMode
import com.sewraywx.autotyping.data.model.TypingConfig
import com.sewraywx.autotyping.data.model.TypingMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("app_prefs")

@Singleton
class AppPrefs @Inject constructor(@ApplicationContext private val ctx: Context) {

    private object Keys {
        val CONTROL_MODE  = intPreferencesKey("control_mode")
        val TYPING_MODE   = intPreferencesKey("typing_mode")
        val CHAR_DELAY    = floatPreferencesKey("char_delay")
        val MSG_DELAY     = floatPreferencesKey("msg_delay")
        val PREFIX        = stringPreferencesKey("prefix")
        val SUFFIX        = stringPreferencesKey("suffix")
        val USE_VOL_KEY   = booleanPreferencesKey("use_vol_key")
        val ADB_IP        = stringPreferencesKey("adb_ip")
        val FLOAT_BTN_X   = floatPreferencesKey("float_x")
        val FLOAT_BTN_Y   = floatPreferencesKey("float_y")
    }

    val config: Flow<TypingConfig> = ctx.dataStore.data.map { prefs ->
        TypingConfig(
            controlMode  = if (prefs[Keys.CONTROL_MODE] == 1) ControlMode.ACCESSIBILITY else ControlMode.ADB,
            typingMode   = if (prefs[Keys.TYPING_MODE] == 2) TypingMode.FAST else TypingMode.BALANCED,
            charDelay    = prefs[Keys.CHAR_DELAY]  ?: 0.03f,
            msgDelay     = prefs[Keys.MSG_DELAY]   ?: 0.5f,
            prefix       = prefs[Keys.PREFIX]      ?: "",
            suffix       = prefs[Keys.SUFFIX]      ?: "",
            useVolumeKey = prefs[Keys.USE_VOL_KEY] ?: true,
            adbIp        = prefs[Keys.ADB_IP]      ?: ""
        )
    }

    suspend fun saveConfig(cfg: TypingConfig) {
        ctx.dataStore.edit { prefs ->
            prefs[Keys.CONTROL_MODE]  = if (cfg.controlMode == ControlMode.ACCESSIBILITY) 1 else 0
            prefs[Keys.TYPING_MODE]   = if (cfg.typingMode  == TypingMode.FAST) 2 else 1
            prefs[Keys.CHAR_DELAY]    = cfg.charDelay
            prefs[Keys.MSG_DELAY]     = cfg.msgDelay
            prefs[Keys.PREFIX]        = cfg.prefix
            prefs[Keys.SUFFIX]        = cfg.suffix
            prefs[Keys.USE_VOL_KEY]   = cfg.useVolumeKey
            prefs[Keys.ADB_IP]        = cfg.adbIp
        }
    }

    suspend fun saveFloatPos(x: Float, y: Float) {
        ctx.dataStore.edit { prefs ->
            prefs[Keys.FLOAT_BTN_X] = x
            prefs[Keys.FLOAT_BTN_Y] = y
        }
    }

    val floatPos: Flow<Pair<Float, Float>> = ctx.dataStore.data.map { prefs ->
        (prefs[Keys.FLOAT_BTN_X] ?: -1f) to (prefs[Keys.FLOAT_BTN_Y] ?: -1f)
    }
}
