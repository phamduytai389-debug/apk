package com.sewraywx.autotyping.ui.files

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.sewraywx.autotyping.data.model.TxtFileEntity
import com.sewraywx.autotyping.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(
    onBack: () -> Unit,
    vm    : FilesViewModel = hiltViewModel()
) {
    val files   by vm.files.collectAsState()
    val scope   = rememberCoroutineScope()
    val snackHost = remember { SnackbarHostState() }

    // Handle messages
    LaunchedEffect(Unit) {
        vm.message.collect { snackHost.showSnackbar(it) }
    }

    // File picker launcher
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { vm.importFile(it) } }

    // State
    var previewFile  by remember { mutableStateOf<TxtFileEntity?>(null) }
    var addLineFile  by remember { mutableStateOf<TxtFileEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<TxtFileEntity?>(null) }

    Scaffold(
        containerColor  = BgDeep,
        snackbarHost    = { SnackbarHost(snackHost) },
        topBar = {
            TopAppBar(
                title = { Text("Quản lý file", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                actions = {
                    IconButton(onClick = { picker.launch(arrayOf("text/plain", "*/*")) }) {
                        Icon(Icons.Default.Add, null, tint = AccentBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDeep)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick          = { picker.launch(arrayOf("text/plain")) },
                containerColor   = AccentBlue,
                contentColor     = Color.White,
                shape            = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.UploadFile, "Import .txt")
            }
        }
    ) { pad ->
        if (files.isEmpty()) {
            EmptyState(Modifier.fillMaxSize().padding(pad))
        } else {
            LazyColumn(
                modifier            = Modifier.fillMaxSize().padding(pad),
                contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(files, key = { it.id }) { file ->
                    FileCard(
                        file      = file,
                        onSelect  = { vm.setActive(file) },
                        onPreview = { previewFile = file },
                        onAddLine = { addLineFile = file },
                        onDelete  = { deleteTarget = file }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    // Dialogs
    previewFile?.let { file ->
        PreviewDialog(
            file     = file,
            lines    = vm.previewLines(file),
            onDismiss = { previewFile = null }
        )
    }

    addLineFile?.let { file ->
        AddLineDialog(
            file      = file,
            onConfirm = { line -> scope.launch { vm.addLine(file, line) }; addLineFile = null },
            onDismiss = { addLineFile = null }
        )
    }

    deleteTarget?.let { file ->
        DeleteConfirmDialog(
            fileName  = file.name,
            onConfirm = { vm.delete(file); deleteTarget = null },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun FileCard(
    file     : TxtFileEntity,
    onSelect : () -> Unit,
    onPreview: () -> Unit,
    onAddLine: () -> Unit,
    onDelete : () -> Unit
) {
    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = if (file.isActive) AccentBlue.copy(alpha = 0.1f) else BgSurface,
        border = BorderStroke(
            1.dp,
            if (file.isActive) AccentBlue.copy(alpha = 0.5f) else DividerColor
        )
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Active indicator
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(40.dp)
                    .background(
                        color = if (file.isActive) AccentBlue else Color.Transparent,
                        shape = RoundedCornerShape(2.dp)
                    )
            )
            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    file.name,
                    color      = TextPrimary,
                    fontWeight = if (file.isActive) FontWeight.Bold else FontWeight.Normal,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis
                )
                Text(
                    "${file.lineCount} dòng  •  ${file.sizeBytes / 1024} KB",
                    color    = TextSecond,
                    fontSize = 12.sp
                )
            }

            // Actions
            Row {
                if (!file.isActive) {
                    IconButton(onClick = onSelect, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.CheckCircleOutline, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                    }
                } else {
                    Icon(Icons.Default.CheckCircle, null, tint = AccentBlue, modifier = Modifier.size(20.dp).padding(8.dp))
                }
                IconButton(onClick = onPreview, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Preview, null, tint = TextSecond, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onAddLine, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.AddCircleOutline, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.DeleteOutline, null, tint = AccentRed, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.FolderOpen, null, tint = TextSecond, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(16.dp))
            Text("Chưa có file nào", color = TextSecond, fontSize = 16.sp)
            Text("Nhấn + để import file .txt", color = TextSecond, fontSize = 13.sp)
        }
    }
}

@Composable
private fun PreviewDialog(file: TxtFileEntity, lines: List<String>, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = BgSurface
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(file.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Hiển thị tối đa 20 dòng đầu", color = TextSecond, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Divider(color = DividerColor)
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(lines.indices.toList()) { i ->
                        Text(
                            "${i + 1}. ${lines[i]}",
                            color    = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
                Divider(color = DividerColor)
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Đóng", color = AccentBlue)
                }
            }
        }
    }
}

@Composable
private fun AddLineDialog(file: TxtFileEntity, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = BgSurface,
        title            = { Text("Thêm dòng", color = TextPrimary) },
        text = {
            OutlinedTextField(
                value         = text,
                onValueChange = { text = it },
                placeholder   = { Text("Nội dung câu mới…", color = TextSecond) },
                modifier      = Modifier.fillMaxWidth(),
                colors        = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = AccentBlue,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor     = TextPrimary,
                    unfocusedTextColor   = TextPrimary,
                    cursorColor          = AccentBlue
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text) }, enabled = text.isNotBlank()) {
                Text("Thêm", color = AccentGreen)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Huỷ", color = TextSecond) }
        }
    )
}

@Composable
private fun DeleteConfirmDialog(fileName: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = BgSurface,
        icon             = { Icon(Icons.Default.Warning, null, tint = AccentRed) },
        title            = { Text("Xoá file?", color = TextPrimary) },
        text             = { Text("\"$fileName\" sẽ bị xoá vĩnh viễn.", color = TextSecond) },
        confirmButton    = {
            TextButton(onClick = onConfirm) { Text("Xoá", color = AccentRed) }
        },
        dismissButton    = {
            TextButton(onClick = onDismiss) { Text("Huỷ", color = TextSecond) }
        }
    )
}
