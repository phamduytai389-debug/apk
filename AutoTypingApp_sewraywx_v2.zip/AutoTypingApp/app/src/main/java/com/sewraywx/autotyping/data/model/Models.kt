package com.sewraywx.autotyping.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ── API Models ───────────────────────────────────────────────────

data class VerifyRequest(
    val key: String,
    val hwid: String
)

data class VerifyResponse(
    val valid: Boolean,
    val session_id: String? = null,
    val expire: String? = null,
    val max_ips: Int? = null,
    val current_ips: Int? = null,
    val created_at: String? = null,
    val error: String? = null
)

data class HeartbeatRequest(
    val key: String,
    val session_id: String,
    val hwid: String
)

data class KillCheckRequest(
    val key: String,
    val session_id: String
)

data class KillCheckResponse(
    val kill: Boolean,
    val message: String? = null
)

// ── Room Entity ──────────────────────────────────────────────────

@Entity(tableName = "txt_files")
data class TxtFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val path: String,
    val lineCount: Int = 0,
    val sizeBytes: Long = 0L,
    val isActive: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

// ── App State ────────────────────────────────────────────────────

enum class ControlMode { ADB, ACCESSIBILITY }
enum class TypingMode  { BALANCED, FAST }
enum class RunState    { STOPPED, RUNNING }

data class TypingConfig(
    val controlMode : ControlMode  = ControlMode.ADB,
    val typingMode  : TypingMode   = TypingMode.FAST,
    val charDelay   : Float        = 0.03f,
    val msgDelay    : Float        = 0.5f,
    val prefix      : String       = "",
    val suffix      : String       = "",
    val useVolumeKey: Boolean      = true,
    val adbIp       : String       = ""
)

data class KeyCacheModel(
    val key          : String,
    val sessionId    : String,
    val expireDate   : String,
    val verifiedAt   : Long = System.currentTimeMillis()
)
