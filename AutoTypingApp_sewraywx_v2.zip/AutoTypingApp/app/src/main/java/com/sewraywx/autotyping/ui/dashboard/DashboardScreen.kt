package com.sewraywx.autotyping.ui.dashboard

import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sewraywx.autotyping.data.model.ControlMode
import com.sewraywx.autotyping.data.model.TypingMode
import com.sewraywx.autotyping.ui.theme.*
import com.sewraywx.autotyping.util.formatRemainingTime

@Composable
fun DashboardScreen(
    onNavigateFiles : () -> Unit,
    onNavigateConfig: () -> Unit,
    onLogout        : () -> Unit,
    vm              : DashboardViewModel = hiltViewModel()
) {
    val ctx         = LocalContext.current
    val config      by vm.config.collectAsState()
    val isRunning   by vm.isRunning.collectAsState()
    val progress    by vm.sentProgress.collectAsState()
    val activeFile  by vm.activeFile.collectAsState()
    val expireMs    by vm.keyExpireMs.collectAsState()
    val accessOk    = vm.accessibilityEnabled

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopBarRow(
                expireMs    = expireMs,
                onConfig    = onNavigateConfig,
                onLogout    = onLogout
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // ── Big control button ─────────────────────────────────
            BigControlButton(
                isRunning   = isRunning,
                hasFile     = activeFile != null,
                onStart     = { vm.startTyping() },
                onStop      = { vm.stopTyping() }
            )

            // ── Progress card ──────────────────────────────────────
            AnimatedVisibility(visible = isRunning) {
                ProgressCard(current = progress.first, total = progress.second)
            }

            // ── Active file card ───────────────────────────────────
            ActiveFileCard(
                file     = activeFile?.name,
                lines    = activeFile?.lineCount ?: 0,
                onClick  = onNavigateFiles
            )

            // ── Mode badges ────────────────────────────────────────
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeBadge(
                    label = "Control",
                    value = if (config.controlMode == ControlMode.ADB) "ADB" else "Accessibility",
                    color = AccentBlue
                )
                ModeBadge(
                    label = "Typing",
                    value = if (config.typingMode == TypingMode.FAST) "Fast" else "Balanced",
                    color = AccentGreen
                )
                ModeBadge(
                    label = "Vol Key",
                    value = if (config.useVolumeKey) "ON" else "OFF",
                    color = if (config.useVolumeKey) AccentGreen else TextSecond
                )
            }

            // ── Prefix / Suffix quick preview ──────────────────────
            if (config.prefix.isNotBlank() || config.suffix.isNotBlank()) {
                PrefixSuffixCard(prefix = config.prefix, suffix = config.suffix)
            }

            // ── Permission warnings ────────────────────────────────
            if (config.controlMode == ControlMode.ACCESSIBILITY && !accessOk) {
                PermissionWarningCard(
                    icon    = Icons.Default.Accessibility,
                    text    = "Cần bật Accessibility Service",
                    action  = "Bật",
                    onClick = { vm.openAccessibilitySettings() }
                )
            }
            if (!Settings.canDrawOverlays(ctx)) {
                PermissionWarningCard(
                    icon    = Icons.Default.Window,
                    text    = "Cần quyền hiển thị nút nổi",
                    action  = "Cấp",
                    onClick = { vm.openOverlaySettings() }
                )
            }

            // ── Floating window toggle ─────────────────────────────
            var floatActive by remember { mutableStateOf(false) }
            OutlinedButton(
                onClick  = { floatActive = !floatActive; vm.toggleFloatingWindow(floatActive) },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(10.dp),
                border   = BorderStroke(1.dp, DividerColor)
            ) {
                Icon(
                    if (floatActive) Icons.Default.PictureInPicture else Icons.Default.PictureInPictureAlt,
                    null,
                    tint = if (floatActive) AccentBlue else TextSecond
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (floatActive) "Ẩn nút nổi" else "Hiện nút nổi",
                    color = if (floatActive) AccentBlue else TextSecond
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── Components ────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopBarRow(expireMs: Long, onConfig: () -> Unit, onLogout: () -> Unit) {
    TopAppBar(
        title = {
            Column {
                Text("Sewraywx Auto", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Hết hạn: ${formatRemainingTime(expireMs)}",
                    fontSize = 11.sp,
                    color = if (expireMs > 3 * 24 * 3600 * 1000L) AccentGreen else AccentYellow
                )
            }
        },
        actions = {
            IconButton(onClick = onConfig) {
                Icon(Icons.Default.Settings, null, tint = TextSecond)
            }
            IconButton(onClick = onLogout) {
                Icon(Icons.Default.Logout, null, tint = AccentRed)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDeep)
    )
}

@Composable
private fun BigControlButton(
    isRunning: Boolean,
    hasFile  : Boolean,
    onStart  : () -> Unit,
    onStop   : () -> Unit
) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue   = 1f,
        targetValue    = if (isRunning) 1.05f else 1f,
        animationSpec  = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label          = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .scale(pulse)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isRunning) BgElevated else BgSurface)
            .border(
                BorderStroke(
                    2.dp,
                    if (isRunning) AccentGreen else if (hasFile) AccentBlue else DividerColor
                ),
                RoundedCornerShape(20.dp)
            )
            .clickable(enabled = hasFile) { if (isRunning) onStop() else onStart() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = when {
                    isRunning -> AccentGreen
                    hasFile   -> AccentBlue
                    else      -> TextSecond
                },
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = when {
                    isRunning  -> "ĐANG CHẠY — Nhấn để dừng"
                    hasFile    -> "NHẤN ĐỂ BẮT ĐẦU"
                    else       -> "Chưa chọn file"
                },
                color = when {
                    isRunning -> AccentGreen
                    hasFile   -> TextPrimary
                    else      -> TextSecond
                },
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun ProgressCard(current: Int, total: Int) {
    val progress = if (total > 0) current.toFloat() / total else 0f

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = BgSurface,
        border = BorderStroke(1.dp, DividerColor)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Tiến độ", color = TextSecond, fontSize = 12.sp)
                Text("$current / $total", color = TextPrimary, fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress     = { progress },
                modifier     = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color        = AccentGreen,
                trackColor   = BgElevated
            )
        }
    }
}

@Composable
private fun ActiveFileCard(file: String?, lines: Int, onClick: () -> Unit) {
    Surface(
        shape  = RoundedCornerShape(12.dp),
        color  = BgSurface,
        border = BorderStroke(1.dp, DividerColor),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.TextSnippet, null,
                tint = if (file != null) AccentBlue else TextSecond,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    file ?: "Chưa chọn file",
                    color = if (file != null) TextPrimary else TextSecond,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (file != null) {
                    Text("$lines dòng", color = TextSecond, fontSize = 12.sp)
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextSecond)
        }
    }
}

@Composable
private fun ModeBadge(label: String, value: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 10.sp, color = TextSecond)
            Text(value, fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun PrefixSuffixCard(prefix: String, suffix: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = BgSurface,
        border = BorderStroke(1.dp, DividerColor)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FormatQuote, null, tint = TextSecond, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                buildString {
                    if (prefix.isNotBlank()) append("[${prefix.take(20)}] ")
                    append("câu")
                    if (suffix.isNotBlank()) append(" [${suffix.take(20)}]")
                },
                color = TextSecond,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun PermissionWarningCard(
    icon   : ImageVector,
    text   : String,
    action : String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AccentYellow.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, AccentYellow.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = AccentYellow, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, color = AccentYellow, fontSize = 13.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onClick) {
                Text(action, color = AccentYellow, fontWeight = FontWeight.Bold)
            }
        }
    }
}
