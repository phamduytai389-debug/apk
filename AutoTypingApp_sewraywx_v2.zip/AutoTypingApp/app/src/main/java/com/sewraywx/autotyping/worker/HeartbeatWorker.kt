package com.sewraywx.autotyping.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.sewraywx.autotyping.data.api.KeyApi
import com.sewraywx.autotyping.data.model.KillCheckRequest
import com.sewraywx.autotyping.data.prefs.SecurePrefs
import com.sewraywx.autotyping.util.getHWID
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class HeartbeatWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val api       : KeyApi,
    private val prefs     : SecurePrefs
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val cache = prefs.getKeyCache() ?: return Result.failure()

        // Kiểm tra hết hạn local trước
        if (prefs.getRemainingMs() < 0) {
            prefs.clearKeyCache()
            return Result.failure()
        }

        return try {
            val resp = api.checkKill(
                KillCheckRequest(
                    key        = cache.key,
                    session_id = cache.sessionId
                )
            )
            if (resp.isSuccessful && resp.body()?.kill == true) {
                prefs.clearKeyCache()
                Result.failure()
            } else {
                Result.success()
            }
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "heartbeat_work"

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<HeartbeatWorker>(5, TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 1, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                req
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
