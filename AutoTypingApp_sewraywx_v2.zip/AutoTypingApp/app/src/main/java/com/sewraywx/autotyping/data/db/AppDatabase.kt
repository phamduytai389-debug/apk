package com.sewraywx.autotyping.data.db

import androidx.room.*
import com.sewraywx.autotyping.data.model.TxtFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TxtFileDao {

    @Query("SELECT * FROM txt_files ORDER BY addedAt DESC")
    fun getAllFiles(): Flow<List<TxtFileEntity>>

    @Query("SELECT * FROM txt_files WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveFile(): TxtFileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(file: TxtFileEntity): Long

    @Update
    suspend fun update(file: TxtFileEntity)

    @Delete
    suspend fun delete(file: TxtFileEntity)

    @Query("UPDATE txt_files SET isActive = 0")
    suspend fun clearActive()

    @Query("UPDATE txt_files SET isActive = 1 WHERE id = :id")
    suspend fun setActive(id: Int)

    @Transaction
    suspend fun setActiveFile(id: Int) {
        clearActive()
        setActive(id)
    }

    @Query("UPDATE txt_files SET lineCount = :count, sizeBytes = :size WHERE id = :id")
    suspend fun updateStats(id: Int, count: Int, size: Long)
}

@Database(
    entities = [TxtFileEntity::class],
    version  = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun txtFileDao(): TxtFileDao
}
