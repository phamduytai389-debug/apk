package com.sewraywx.autotyping.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent

class AutoAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance    : AutoAccessibilityService? = null
        @Volatile var pendingText : String? = null
        val isEnabled get() = instance != null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Consume pending text when window changes / focus changes
        val text = pendingText ?: return
        pendingText = null
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        // Press Enter
        performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) // no-op used for timing
        val enterArgs = Bundle()
        node.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        val cfg = TypingService.currentConfig ?: return false
        if (!cfg.useVolumeKey) return false

        if (event?.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    controlTyping(start = true)
                    return true  // chặn volume bar
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    controlTyping(start = false)
                    return true
                }
            }
        }
        return false
    }

    private fun controlTyping(start: Boolean) {
        val ctx = applicationContext
        val intent = Intent(ctx, TypingService::class.java).apply {
            action = if (start) TypingService.ACTION_START else TypingService.ACTION_STOP
        }
        if (start) ctx.startForegroundService(intent)
        else ctx.startService(intent)
    }
}
