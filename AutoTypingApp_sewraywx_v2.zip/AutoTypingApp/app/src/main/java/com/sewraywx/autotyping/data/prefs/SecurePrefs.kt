package com.sewraywx.autotyping.data.prefs

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.sewraywx.autotyping.data.model.KeyCacheModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePrefs @Inject constructor(@ApplicationContext private val ctx: Context) {

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(ctx)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            ctx, "sewraywx_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ── Key cache ────────────────────────────────────────────────

    fun saveKeyCache(model: KeyCacheModel) {
        prefs.edit()
            .putString("cached_key",         model.key)
            .putString("cached_session",      model.sessionId)
            .putString("cached_expire",       model.expireDate)
            .putLong  ("cached_verified_at",  model.verifiedAt)
            .apply()
    }

    fun getKeyCache(): KeyCacheModel? {
        val key       = prefs.getString("cached_key",     null) ?: return null
        val session   = prefs.getString("cached_session", null) ?: return null
        val expire    = prefs.getString("cached_expire",  null) ?: return null
        val verifiedAt = prefs.getLong ("cached_verified_at", 0L)
        return KeyCacheModel(key, session, expire, verifiedAt)
    }

    fun clearKeyCache() {
        prefs.edit()
            .remove("cached_key")
            .remove("cached_session")
            .remove("cached_expire")
            .remove("cached_verified_at")
            .apply()
    }

    /** Trả về số milli-giây còn lại. Âm = đã hết hạn. */
    fun getRemainingMs(): Long {
        val expire = prefs.getString("cached_expire", null) ?: return -1L
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val expireDate = fmt.parse(expire) ?: return -1L
            expireDate.time - System.currentTimeMillis()
        } catch (e: Exception) {
            -1L
        }
    }

    // ── Rate limiter ─────────────────────────────────────────────

    fun getFailedAttempts(): Int   = prefs.getInt("fail_attempts", 0)
    fun getLastFailTime(): Long    = prefs.getLong("last_fail_time", 0L)

    fun recordFailedAttempt() {
        prefs.edit()
            .putInt("fail_attempts", getFailedAttempts() + 1)
            .putLong("last_fail_time", System.currentTimeMillis())
            .apply()
    }

    fun resetFailedAttempts() {
        prefs.edit()
            .putInt("fail_attempts", 0)
            .putLong("last_fail_time", 0L)
            .apply()
    }

    fun canAttemptVerify(): Boolean {
        val attempts  = getFailedAttempts()
        val lastTime  = getLastFailTime()
        val elapsed   = System.currentTimeMillis() - lastTime
        if (elapsed > 10 * 60 * 1000L) { resetFailedAttempts(); return true }
        return attempts < 5
    }

    fun lockoutRemainingMs(): Long {
        val lastTime = getLastFailTime()
        val elapsed  = System.currentTimeMillis() - lastTime
        return (10 * 60 * 1000L - elapsed).coerceAtLeast(0L)
    }
}
