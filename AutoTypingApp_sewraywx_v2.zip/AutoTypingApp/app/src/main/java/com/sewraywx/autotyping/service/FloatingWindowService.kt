package com.sewraywx.autotyping.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.sewraywx.autotyping.MainActivity

class FloatingWindowService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var floatView: View
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createFloatView()
    }

    private fun createFloatView() {
        floatView = FrameLayout(this).apply {
            val btn = TextView(context).apply {
                text = "⏸"
                textSize = 18f
                setPadding(24, 16, 24, 16)
                setBackgroundColor(0xFF1565C0.toInt())
                setTextColor(0xFFFFFFFF.toInt())
            }
            addView(btn)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 200
        }

        // Drag
        var dX = 0f; var dY = 0f
        floatView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { dX = params.x - event.rawX; dY = params.y - event.rawY; false }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (event.rawX + dX).toInt()
                    params.y = (event.rawY + dY).toInt()
                    wm.updateViewLayout(floatView, params); true
                }
                else -> false
            }
        }

        floatView.setOnClickListener { toggleTyping() }
        floatView.setOnLongClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }); true
        }

        wm.addView(floatView, params)
        updateAppearance()
    }

    private fun toggleTyping() {
        val action = if (TypingService.isRunning) TypingService.ACTION_STOP else TypingService.ACTION_START
        val intent = Intent(this, TypingService::class.java).apply { this.action = action }
        if (!TypingService.isRunning) startForegroundService(intent) else startService(intent)
        updateAppearance()
    }

    private fun updateAppearance() {
        val btn = (floatView as FrameLayout).getChildAt(0) as TextView
        if (TypingService.isRunning) {
            btn.text = "▶ ${TypingService.currentIndex}/${TypingService.totalSentences}"
            btn.setBackgroundColor(0xFF2E7D32.toInt())
        } else {
            btn.text = "⏸ Chờ"
            btn.setBackgroundColor(0xFFB71C1C.toInt())
        }
    }

    override fun onDestroy() {
        if (::floatView.isInitialized) wm.removeView(floatView)
        super.onDestroy()
    }
}
