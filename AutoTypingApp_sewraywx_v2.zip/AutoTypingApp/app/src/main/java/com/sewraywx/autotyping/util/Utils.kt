package com.sewraywx.autotyping.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

// ── HWID ─────────────────────────────────────────────────────────

fun getHWID(context: Context): String {
    val androidId = Settings.Secure.getString(
        context.contentResolver, Settings.Secure.ANDROID_ID
    ) ?: "unknown"
    @Suppress("DEPRECATION")
    val serial = Build.SERIAL ?: "noserial"
    val raw = "${androidId}_${Build.MANUFACTURER}_${Build.MODEL}_$serial"
    return sha256(raw).take(32)
}

private fun sha256(input: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

// ── Validation ───────────────────────────────────────────────────

fun isValidKeyFormat(key: String): Boolean {
    // Accepts "WORD", "WORD_SUFFIX6", or "A-B-C-D" formats
    if (key.isBlank() || key.length > 50) return false
    return key.none { it.isWhitespace() }
}

fun isValidIp(ip: String): Boolean {
    val pattern = Regex("""^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d{1,5})?$""")
    return ip.matches(pattern)
}

fun sanitizeText(input: String): String =
    input.take(500).replace("\u0000", "").trim()

// ── Time helpers ─────────────────────────────────────────────────

fun formatRemainingTime(ms: Long): String {
    if (ms <= 0) return "Đã hết hạn"
    val days    = TimeUnit.MILLISECONDS.toDays(ms)
    val hours   = TimeUnit.MILLISECONDS.toHours(ms) % 24
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
    return when {
        days > 0  -> "$days ngày $hours giờ $minutes phút"
        hours > 0 -> "$hours giờ $minutes phút"
        else      -> "$minutes phút"
    }
}

fun formatLockoutTime(ms: Long): String {
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return "${minutes}:${seconds.toString().padStart(2, '0')}"
}
