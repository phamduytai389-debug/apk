package com.sewraywx.autotyping.ui.files

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sewraywx.autotyping.data.db.TxtFileDao
import com.sewraywx.autotyping.data.model.TxtFileEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val dao: TxtFileDao,
    @ApplicationContext private val ctx: Context
) : ViewModel() {

    val files: StateFlow<List<TxtFileEntity>> = dao.getAllFiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableSharedFlow<String>()
    val message = _message.asSharedFlow()

    fun importFile(uri: Uri) {
        viewModelScope.launch {
            try {
                val cr       = ctx.contentResolver
                val name     = getFileName(cr, uri) ?: "file_${System.currentTimeMillis()}.txt"
                val destDir  = ctx.filesDir.resolve("sentences").also { it.mkdirs() }
                val destFile = destDir.resolve(name.replace(" ", "_"))

                cr.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { out -> input.copyTo(out) }
                } ?: run { _message.emit("Không thể đọc file"); return@launch }

                val lines = destFile.readLines(Charsets.UTF_8).filter { it.isNotBlank() }
                val entity = TxtFileEntity(
                    name      = name,
                    path      = destFile.absolutePath,
                    lineCount = lines.size,
                    sizeBytes = destFile.length()
                )
                dao.insert(entity)
                _message.emit("Đã thêm: $name (${lines.size} dòng)")
            } catch (e: Exception) {
                _message.emit("Lỗi: ${e.message}")
            }
        }
    }

    fun setActive(file: TxtFileEntity) {
        viewModelScope.launch {
            dao.setActiveFile(file.id)
            _message.emit("Đã chọn: ${file.name}")
        }
    }

    fun delete(file: TxtFileEntity) {
        viewModelScope.launch {
            File(file.path).delete()
            dao.delete(file)
            _message.emit("Đã xoá: ${file.name}")
        }
    }

    fun addLine(file: TxtFileEntity, line: String) {
        viewModelScope.launch {
            try {
                File(file.path).appendText("\n${line.trim()}")
                val newCount = File(file.path).readLines().count { it.isNotBlank() }
                dao.updateStats(file.id, newCount, File(file.path).length())
                _message.emit("Đã thêm dòng")
            } catch (e: Exception) {
                _message.emit("Lỗi ghi file")
            }
        }
    }

    fun previewLines(file: TxtFileEntity): List<String> = try {
        File(file.path).readLines(Charsets.UTF_8).filter { it.isNotBlank() }.take(20)
    } catch (e: Exception) { emptyList() }

    private fun getFileName(cr: android.content.ContentResolver, uri: Uri): String? {
        cr.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getString(0)
        }
        return uri.lastPathSegment
    }
}
