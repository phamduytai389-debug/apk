package com.sewraywx.autotyping.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Palette ─────────────────────────────────────────────────────
val BgDeep       = Color(0xFF0D0F14)   // Nền chính cực tối
val BgSurface    = Color(0xFF161A22)   // Card / surface
val BgElevated   = Color(0xFF1E2330)   // Elevated card
val AccentBlue   = Color(0xFF4D9EFF)   // Accent chính
val AccentGreen  = Color(0xFF3DDC84)   // Trạng thái chạy
val AccentRed    = Color(0xFFFF4D6D)   // Dừng / lỗi
val AccentYellow = Color(0xFFFFD60A)   // Cảnh báo
val TextPrimary  = Color(0xFFE8EBF2)
val TextSecond   = Color(0xFF7A8499)
val DividerColor = Color(0xFF252B38)

private val DarkColorScheme = darkColorScheme(
    primary          = AccentBlue,
    onPrimary        = Color(0xFF001C38),
    primaryContainer = Color(0xFF00366A),
    secondary        = AccentGreen,
    onSecondary      = Color(0xFF003919),
    error            = AccentRed,
    background       = BgDeep,
    onBackground     = TextPrimary,
    surface          = BgSurface,
    onSurface        = TextPrimary,
    surfaceVariant   = BgElevated,
    onSurfaceVariant = TextSecond,
    outline          = DividerColor,
)

@Composable
fun AutoTypingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = Typography(),
        content     = content
    )
}
