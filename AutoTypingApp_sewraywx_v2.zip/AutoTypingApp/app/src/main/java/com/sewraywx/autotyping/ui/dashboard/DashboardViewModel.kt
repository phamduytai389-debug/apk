package com.sewraywx.autotyping.ui.dashboard

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sewraywx.autotyping.data.db.TxtFileDao
import com.sewraywx.autotyping.data.model.TxtFileEntity
import com.sewraywx.autotyping.data.model.TypingConfig
import com.sewraywx.autotyping.data.prefs.AppPrefs
import com.sewraywx.autotyping.data.prefs.SecurePrefs
import com.sewraywx.autotyping.service.AutoAccessibilityService
import com.sewraywx.autotyping.service.FloatingWindowService
import com.sewraywx.autotyping.service.TypingService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val dao       : TxtFileDao,
    private val appPrefs  : AppPrefs,
    private val secPrefs  : SecurePrefs,
    @ApplicationContext private val ctx: Context
) : ViewModel() {

    val config: StateFlow<TypingConfig> = appPrefs.config
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TypingConfig())

    val activeFile: StateFlow<TxtFileEntity?> = dao.getAllFiles()
        .map { list -> list.firstOrNull { it.isActive } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val _sentProgress = MutableStateFlow(0 to 0)   // current to total
    val sentProgress: StateFlow<Pair<Int, Int>> = _sentProgress

    val keyExpireMs: StateFlow<Long> = flow {
        while (true) { emit(secPrefs.getRemainingMs()); delay(60_000L) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val accessibilityEnabled get() = AutoAccessibilityService.isEnabled

    init {
        // Poll running state + progress from TypingService
        viewModelScope.launch {
            while (true) {
                _isRunning.value = TypingService.isRunning
                _sentProgress.value = TypingService.currentIndex to TypingService.totalSentences
                delay(500L)
            }
        }
    }

    fun startTyping() {
        val cfg  = config.value
        val file = activeFile.value ?: return

        TypingService.currentConfig  = cfg
        TypingService.activeFilePath = file.path

        ctx.startForegroundService(
            Intent(ctx, TypingService::class.java).apply { action = TypingService.ACTION_START }
        )
    }

    fun stopTyping() {
        ctx.startService(
            Intent(ctx, TypingService::class.java).apply { action = TypingService.ACTION_STOP }
        )
    }

    fun toggleFloatingWindow(show: Boolean) {
        if (!Settings.canDrawOverlays(ctx)) return
        val intent = Intent(ctx, FloatingWindowService::class.java)
        if (show) ctx.startService(intent) else ctx.stopService(intent)
    }

    fun saveConfig(cfg: TypingConfig) {
        viewModelScope.launch { appPrefs.saveConfig(cfg) }
        // Cập nhật live cho service đang chạy
        TypingService.currentConfig = cfg
    }

    fun openAccessibilitySettings() {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    fun openOverlaySettings() {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }
}
