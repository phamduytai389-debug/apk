package com.sewraywx.autotyping.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import com.sewraywx.autotyping.MainActivity
import com.sewraywx.autotyping.data.model.ControlMode
import com.sewraywx.autotyping.data.model.TypingConfig
import com.sewraywx.autotyping.data.model.TypingMode
import kotlinx.coroutines.*
import java.io.File

class TypingService : Service() {

    companion object {
        const val CHANNEL_ID   = "typing_channel"
        const val NOTIF_ID     = 1001
        const val ACTION_START = "START"
        const val ACTION_STOP  = "STOP"
        const val EXTRA_CONFIG = "config_json"

        // Shared state (accessed from Accessibility/Floating also)
        @Volatile var isRunning     = false
        @Volatile var currentIndex  = 0
        @Volatile var totalSentences = 0
        @Volatile var currentConfig : TypingConfig? = null
        @Volatile var sentences     : List<String>  = emptyList()
        @Volatile var activeFilePath: String        = ""

        private val tag = "TypingService"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val cfg = currentConfig ?: return START_NOT_STICKY
                startForeground(NOTIF_ID, buildNotification("Đang chuẩn bị…"))
                scope.launch { runSpamLoop(cfg) }
            }
            ACTION_STOP  -> {
                isRunning = false
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun runSpamLoop(cfg: TypingConfig) {
        sentences = loadSentences(activeFilePath)
        if (sentences.isEmpty()) {
            stopSelf(); return
        }
        totalSentences = sentences.size
        isRunning = true
        currentIndex = 0

        while (isRunning) {
            for (i in sentences.indices) {
                if (!isRunning) break
                currentIndex = i + 1

                val fullMsg = "${cfg.prefix}${sentences[i]}${cfg.suffix}"
                updateNotification("Câu $currentIndex/$totalSentences")

                val tStart = System.nanoTime()
                val ok = when (cfg.controlMode) {
                    ControlMode.ADB           -> sendViaAdb(fullMsg, cfg)
                    ControlMode.ACCESSIBILITY -> sendViaAccessibility(fullMsg)
                }
                if (ok) pressEnterAdb(cfg)

                val elapsed = (System.nanoTime() - tStart) / 1_000_000_000.0
                val remain  = cfg.msgDelay - elapsed
                if (remain > 0) delay((remain * 1000).toLong())
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── ADB engine ───────────────────────────────────────────────

    private fun adb(cfg: TypingConfig): Array<String> {
        val ip = cfg.adbIp
        return if (ip.isNotBlank()) arrayOf("adb", "-s", ip)
        else arrayOf("adb")
    }

    private fun sendViaAdb(text: String, cfg: TypingConfig): Boolean {
        return if (cfg.typingMode == TypingMode.FAST) sendFast(text, cfg)
        else sendBalanced(text, cfg)
    }

    private fun sendFast(text: String, cfg: TypingConfig): Boolean {
        return try {
            val safe = shellQuote(text)
            val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", "input text $safe"))
            r.waitFor() == 0
        } catch (e: Exception) {
            try {
                val b64 = Base64.encodeToString(text.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                val cmd = "input text \"\$(echo -n $b64 | base64 -d 2>/dev/null)\""
                val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", cmd))
                r.waitFor() == 0
            } catch (ex: Exception) { false }
        }
    }

    private fun sendBalanced(text: String, cfg: TypingConfig): Boolean {
        for (ch in text) {
            if (!isRunning) break
            val t = System.nanoTime()
            try {
                when {
                    ch == ' ' -> {
                        val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", "input", "keyevent", "62"))
                        r.waitFor()
                    }
                    ch.code > 127 -> {
                        val b64 = Base64.encodeToString(ch.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                        val cmd = "input text \"\$(echo -n $b64 | base64 -d 2>/dev/null)\""
                        val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", cmd))
                        r.waitFor()
                    }
                    else -> {
                        val safe = shellQuote(ch.toString())
                        val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", "input text $safe"))
                        r.waitFor()
                    }
                }
            } catch (e: Exception) { /* skip char */ }
            val elapsed = (System.nanoTime() - t) / 1_000_000_000.0
            val rem     = cfg.charDelay - elapsed
            if (rem > 0) Thread.sleep((rem * 1000).toLong())
        }
        return true
    }

    private fun pressEnterAdb(cfg: TypingConfig) {
        try {
            val r = Runtime.getRuntime().exec(adb(cfg) + arrayOf("shell", "input", "keyevent", "66"))
            r.waitFor()
        } catch (e: Exception) { /* ignore */ }
    }

    private fun shellQuote(text: String): String =
        "'" + text.replace("'", "'\"'\"'") + "'"

    // ── Accessibility engine ──────────────────────────────────────

    private fun sendViaAccessibility(text: String): Boolean {
        AutoAccessibilityService.pendingText = text
        return true   // Service picks it up async
    }

    // ── File loading ─────────────────────────────────────────────

    private fun loadSentences(path: String): List<String> {
        if (path.isBlank()) return emptyList()
        return try {
            File(path).readLines(Charsets.UTF_8).filter { it.isNotBlank() }
        } catch (e: Exception) { emptyList() }
    }

    // ── Notification ─────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Auto Typing", NotificationManager.IMPORTANCE_LOW)
        ch.setSound(null, null)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent  = Intent(this, TypingService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        val openIntent  = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Sewraywx Auto đang chạy")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPending)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        super.onDestroy()
    }
}
