package com.sewraywx.autotyping.data.api

import com.sewraywx.autotyping.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface KeyApi {

    @POST("/verify")
    suspend fun verify(@Body request: VerifyRequest): Response<VerifyResponse>

    @POST("/check_kill")
    suspend fun checkKill(@Body request: KillCheckRequest): Response<KillCheckResponse>
}
