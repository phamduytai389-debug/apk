package com.sewraywx.autotyping.ui.auth

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sewraywx.autotyping.ui.theme.*
import com.sewraywx.autotyping.util.formatLockoutTime
import kotlinx.coroutines.delay

@Composable
fun AuthScreen(
    onSuccess: () -> Unit,
    vm: AuthViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsState()
    val keyInput by vm.keyInput.collectAsState()

    LaunchedEffect(state) {
        if (state is AuthState.Success) onSuccess()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep),
        contentAlignment = Alignment.Center
    ) {

        // Subtle gradient top bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(listOf(AccentBlue, AccentGreen))
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(60.dp))

            // Logo / title
            Text(
                text = "SEWRAYWX",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = AccentBlue,
                letterSpacing = 6.sp
            )
            Text(
                text = "AUTO TYPING",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                fontFamily = FontFamily.Monospace,
                color = TextSecond,
                letterSpacing = 4.sp
            )

            Spacer(Modifier.height(48.dp))

            // Key Input Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = BgSurface,
                border = BorderStroke(1.dp, DividerColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        text = "Nhập license key",
                        fontSize = 13.sp,
                        color = TextSecond,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    var showKey by remember { mutableStateOf(false) }
                    val focusReq = remember { FocusRequester() }
                    val keyboard = LocalSoftwareKeyboardController.current

                    OutlinedTextField(
                        value         = keyInput,
                        onValueChange = { vm.keyInput.value = it.trim() },
                        singleLine    = true,
                        modifier      = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusReq),
                        placeholder   = { Text("KEY_XXXXXX", fontFamily = FontFamily.Monospace, color = TextSecond) },
                        visualTransformation = if (showKey) VisualTransformation.None
                                               else PasswordVisualTransformation(),
                        trailingIcon  = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    imageVector = if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = TextSecond
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            imeAction      = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = {
                            keyboard?.hide(); vm.verify()
                        }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor   = AccentBlue,
                            unfocusedBorderColor = DividerColor,
                            focusedTextColor     = TextPrimary,
                            unfocusedTextColor   = TextPrimary,
                            cursorColor          = AccentBlue
                        ),
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
                    )

                    Spacer(Modifier.height(16.dp))

                    // State feedback
                    AnimatedVisibility(visible = state is AuthState.Error) {
                        val msg = (state as? AuthState.Error)?.msg ?: ""
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, null, tint = AccentRed, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(msg, color = AccentRed, fontSize = 13.sp)
                        }
                    }

                    AnimatedVisibility(visible = state is AuthState.Lockout) {
                        LockoutTimer(state as? AuthState.Lockout)
                    }

                    // Verify button
                    Button(
                        onClick  = { keyboard?.hide(); vm.verify() },
                        enabled  = keyInput.isNotBlank() && state !is AuthState.Checking && state !is AuthState.Lockout,
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(10.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        if (state is AuthState.Checking) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color    = TextPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Đang xác thực…")
                        } else {
                            Icon(Icons.Default.VpnKey, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Xác thực", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            Text(
                text = "Key có thể được mua từ admin.\nMỗi key gắn với HWID của thiết bị.",
                color = TextSecond,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun LockoutTimer(state: AuthState.Lockout?) {
    if (state == null) return
    var remaining by remember(state.remainMs) { mutableLongStateOf(state.remainMs) }

    LaunchedEffect(state.remainMs) {
        while (remaining > 0) {
            delay(1000L)
            remaining -= 1000L
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 12.dp)
    ) {
        Icon(Icons.Default.Lock, null, tint = AccentYellow, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            "Thử lại sau ${formatLockoutTime(remaining)}",
            color = AccentYellow,
            fontSize = 13.sp
        )
    }
}
