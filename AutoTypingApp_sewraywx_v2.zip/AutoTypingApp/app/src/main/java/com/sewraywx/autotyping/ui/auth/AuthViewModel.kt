package com.sewraywx.autotyping.ui.auth

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sewraywx.autotyping.data.api.KeyApi
import com.sewraywx.autotyping.data.model.KeyCacheModel
import com.sewraywx.autotyping.data.model.VerifyRequest
import com.sewraywx.autotyping.data.prefs.SecurePrefs
import com.sewraywx.autotyping.util.getHWID
import com.sewraywx.autotyping.util.isValidKeyFormat
import com.sewraywx.autotyping.worker.HeartbeatWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class AuthState {
    object Idle       : AuthState()
    object Checking   : AuthState()
    object Success    : AuthState()
    data class Error(val msg: String) : AuthState()
    data class Lockout(val remainMs: Long) : AuthState()
}

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val api   : KeyApi,
    private val prefs : SecurePrefs,
    @ApplicationContext private val ctx: Context
) : ViewModel() {

    private val _state = MutableStateFlow<AuthState>(AuthState.Idle)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    val keyInput = MutableStateFlow("")

    init { checkCachedKey() }

    private fun checkCachedKey() {
        val cache = prefs.getKeyCache() ?: return
        val remaining = prefs.getRemainingMs()
        if (remaining > 0) {
            _state.value = AuthState.Success
            HeartbeatWorker.schedule(ctx)
        } else {
            prefs.clearKeyCache()
        }
    }

    fun verify() {
        val key = keyInput.value.trim()

        if (!isValidKeyFormat(key)) {
            _state.value = AuthState.Error("Định dạng key không hợp lệ"); return
        }
        if (!prefs.canAttemptVerify()) {
            _state.value = AuthState.Lockout(prefs.lockoutRemainingMs()); return
        }

        viewModelScope.launch {
            _state.value = AuthState.Checking
            try {
                val hwid = getHWID(ctx)
                val resp = api.verify(VerifyRequest(key = key, hwid = hwid))
                val body = resp.body()

                if (resp.isSuccessful && body?.valid == true) {
                    prefs.resetFailedAttempts()
                    prefs.saveKeyCache(
                        KeyCacheModel(
                            key       = key,
                            sessionId = body.session_id ?: "",
                            expireDate = body.expire    ?: ""
                        )
                    )
                    HeartbeatWorker.schedule(ctx)
                    _state.value = AuthState.Success
                } else {
                    prefs.recordFailedAttempt()
                    val msg = body?.error ?: "Key không hợp lệ hoặc đã hết hạn"
                    _state.value = AuthState.Error(msg)
                }
            } catch (e: Exception) {
                _state.value = AuthState.Error("Không thể kết nối server: ${e.message}")
            }
        }
    }

    fun logout() {
        prefs.clearKeyCache()
        HeartbeatWorker.cancel(ctx)
        _state.value = AuthState.Idle
        keyInput.value = ""
    }
}
