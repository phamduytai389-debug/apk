package com.sewraywx.autotyping.ui.dashboard

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sewraywx.autotyping.data.model.ControlMode
import com.sewraywx.autotyping.data.model.TypingConfig
import com.sewraywx.autotyping.data.model.TypingMode
import com.sewraywx.autotyping.ui.theme.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigScreen(
    onBack: () -> Unit,
    vm    : DashboardViewModel = hiltViewModel()
) {
    val config by vm.config.collectAsState()
    var local  by remember(config) { mutableStateOf(config) }

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("Cài đặt", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                actions = {
                    TextButton(onClick = { vm.saveConfig(local); onBack() }) {
                        Text("Lưu", color = AccentBlue, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDeep)
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // ── Control Mode ──────────────────────────────────────
            SectionCard(title = "Phương thức điều khiển") {
                SegmentedRow(
                    options  = listOf("ADB", "Accessibility"),
                    selected = if (local.controlMode == ControlMode.ADB) 0 else 1,
                    onSelect = { i ->
                        local = local.copy(
                            controlMode = if (i == 0) ControlMode.ADB else ControlMode.ACCESSIBILITY
                        )
                    }
                )
                if (local.controlMode == ControlMode.ADB) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value         = local.adbIp,
                        onValueChange = { local = local.copy(adbIp = it) },
                        label         = { Text("ADB IP:Port (để trống = USB)") },
                        placeholder   = { Text("192.168.1.10:5555", color = TextSecond) },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth(),
                        colors        = fieldColors(),
                        textStyle     = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            }

            // ── Typing Mode ───────────────────────────────────────
            SectionCard(title = "Chế độ gõ") {
                SegmentedRow(
                    options  = listOf("Fast (paste)", "Balanced (char)"),
                    selected = if (local.typingMode == TypingMode.FAST) 0 else 1,
                    onSelect = { i ->
                        local = local.copy(typingMode = if (i == 0) TypingMode.FAST else TypingMode.BALANCED)
                    }
                )
                Spacer(Modifier.height(12.dp))

                if (local.typingMode == TypingMode.BALANCED) {
                    SliderRow(
                        label  = "Delay giữa ký tự",
                        value  = local.charDelay,
                        range  = 0.01f..0.2f,
                        unit   = "s",
                        onVal  = { local = local.copy(charDelay = it) }
                    )
                    Spacer(Modifier.height(8.dp))
                }

                SliderRow(
                    label  = "Delay giữa câu",
                    value  = local.msgDelay,
                    range  = 0.1f..5f,
                    unit   = "s",
                    onVal  = { local = local.copy(msgDelay = it) }
                )
            }

            // ── Prefix / Suffix ───────────────────────────────────
            SectionCard(title = "Tiền tố / Hậu tố") {
                OutlinedTextField(
                    value         = local.prefix,
                    onValueChange = { local = local.copy(prefix = it) },
                    label         = { Text("Prefix (tiền tố)") },
                    singleLine    = true,
                    modifier      = Modifier.fillMaxWidth(),
                    colors        = fieldColors()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value         = local.suffix,
                    onValueChange = { local = local.copy(suffix = it) },
                    label         = { Text("Suffix (hậu tố)") },
                    singleLine    = true,
                    modifier      = Modifier.fillMaxWidth(),
                    colors        = fieldColors()
                )
                Spacer(Modifier.height(8.dp))
                if (local.prefix.isNotBlank() || local.suffix.isNotBlank()) {
                    Text(
                        "Preview: ${local.prefix}(câu)${local.suffix}",
                        color = TextSecond,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // ── Volume Key ────────────────────────────────────────
            SectionCard(title = "Phím âm lượng") {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Dùng Vol+ / Vol- để điều khiển", color = TextPrimary, fontSize = 14.sp)
                        Text("Yêu cầu Accessibility Service", color = TextSecond, fontSize = 12.sp)
                    }
                    Switch(
                        checked         = local.useVolumeKey,
                        onCheckedChange = { local = local.copy(useVolumeKey = it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlue, checkedTrackColor = AccentBlue.copy(alpha = 0.4f))
                    )
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

// ── Shared components ─────────────────────────────────────────────

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = BgSurface,
        border = BorderStroke(1.dp, DividerColor)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                title,
                color = TextSecond,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            content()
        }
    }
}

@Composable
private fun SegmentedRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, DividerColor), RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        horizontalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        options.forEachIndexed { i, opt ->
            val isSelected = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (isSelected) AccentBlue.copy(alpha = 0.15f) else BgSurface)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    opt,
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) AccentBlue else TextSecond
                )
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onVal: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextPrimary, fontSize = 13.sp)
            Text("${"%.2f".format(value)}$unit", color = AccentBlue, fontSize = 13.sp,
                fontFamily = FontFamily.Monospace)
        }
        Slider(
            value         = value,
            onValueChange = onVal,
            valueRange    = range,
            modifier      = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(
                thumbColor       = AccentBlue,
                activeTrackColor = AccentBlue
            )
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = AccentBlue,
    unfocusedBorderColor = DividerColor,
    focusedTextColor     = TextPrimary,
    unfocusedTextColor   = TextPrimary,
    focusedLabelColor    = AccentBlue,
    unfocusedLabelColor  = TextSecond,
    cursorColor          = AccentBlue
)
