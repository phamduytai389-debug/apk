package com.sewraywx.autotyping

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.*
import com.sewraywx.autotyping.ui.auth.AuthScreen
import com.sewraywx.autotyping.ui.auth.AuthState
import com.sewraywx.autotyping.ui.auth.AuthViewModel
import com.sewraywx.autotyping.ui.dashboard.ConfigScreen
import com.sewraywx.autotyping.ui.dashboard.DashboardScreen
import com.sewraywx.autotyping.ui.files.FilesScreen
import com.sewraywx.autotyping.ui.theme.AutoTypingTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AutoTypingTheme { AppNav() }
        }
    }
}

@Composable
private fun AppNav() {
    val navController = rememberNavController()
    val authVm: AuthViewModel = hiltViewModel()
    val authState by authVm.state.collectAsState()

    // Determine start destination
    val start = if (authState is AuthState.Success) "dashboard" else "auth"

    NavHost(navController = navController, startDestination = start) {

        composable("auth") {
            AuthScreen(
                onSuccess = {
                    navController.navigate("dashboard") {
                        popUpTo("auth") { inclusive = true }
                    }
                },
                vm = authVm
            )
        }

        composable("dashboard") {
            DashboardScreen(
                onNavigateFiles  = { navController.navigate("files") },
                onNavigateConfig = { navController.navigate("config") },
                onLogout = {
                    authVm.logout()
                    navController.navigate("auth") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                }
            )
        }

        composable("files") {
            FilesScreen(onBack = { navController.popBackStack() })
        }

        composable("config") {
            ConfigScreen(onBack = { navController.popBackStack() })
        }
    }
}
