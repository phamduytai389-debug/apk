# Sewraywx Auto Typing — Android App

Ứng dụng Android tương ứng với `go1claude.py` + `key.py`, viết bằng Kotlin/Compose.

---

## Cấu trúc project

```
AutoTypingApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/sewraywx/autotyping/
│   │   │   ├── AutoApp.kt              ← Application (Hilt)
│   │   │   ├── MainActivity.kt         ← Navigation chính
│   │   │   ├── data/
│   │   │   │   ├── api/KeyApi.kt       ← Retrofit API (/verify, /check_kill)
│   │   │   │   ├── db/AppDatabase.kt   ← Room DB + DAO
│   │   │   │   ├── model/Models.kt     ← Data classes
│   │   │   │   └── prefs/
│   │   │   │       ├── SecurePrefs.kt  ← EncryptedSharedPreferences (key cache, rate limit)
│   │   │   │       └── AppPrefs.kt     ← DataStore (config typing)
│   │   │   ├── di/AppModule.kt         ← Hilt DI
│   │   │   ├── service/
│   │   │   │   ├── TypingService.kt    ← Foreground service (spam loop, ADB engine)
│   │   │   │   ├── AutoAccessibilityService.kt ← Volume key + paste
│   │   │   │   ├── FloatingWindowService.kt    ← Nút nổi overlay
│   │   │   │   └── BootReceiver.kt
│   │   │   ├── ui/
│   │   │   │   ├── auth/               ← Màn hình nhập key
│   │   │   │   ├── dashboard/          ← Màn hình chính + cài đặt
│   │   │   │   ├── files/              ← Quản lý file .txt
│   │   │   │   └── theme/Theme.kt      ← Dark theme
│   │   │   ├── util/Utils.kt           ← HWID, validation, formatters
│   │   │   └── worker/HeartbeatWorker.kt ← Kiểm tra kill mỗi 5 phút
│   │   └── res/
│   │       ├── xml/accessibility_service_config.xml
│   │       ├── xml/network_security_config.xml
│   │       └── values/strings.xml, themes.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── gradle/libs.versions.toml
├── build.gradle.kts
└── settings.gradle.kts
```

---

## Build nhanh

### 1. Cấu hình SERVER_URL

Tạo file `local.properties` ở root project (cùng chỗ với `gradle.properties`):

```properties
sdk.dir=/path/to/Android/Sdk
SERVER_URL=http://192.168.1.100:21213
```

Hoặc sửa trực tiếp fallback trong `app/build.gradle.kts`:
```kotlin
buildConfigField("String", "SERVER_URL", "\"http://YOUR_SERVER:21213\"")
```

### 2. Build & install

```bash
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Quyền cần cấp sau khi cài

| Quyền | Cách bật |
|-------|----------|
| **Accessibility Service** | Cài đặt → Trợ năng → Sewraywx Auto Typing → Bật |
| **Hiển thị trên ứng dụng khác** | App sẽ hỏi khi cần, hoặc Cài đặt → Ứng dụng → Sewraywx → Hiển thị trên ứng dụng |
| **ADB (tuỳ chọn)** | `adb tcpip 5555` trên thiết bị |

---

## Chế độ hoạt động

### ADB Mode
- Gõ qua `adb shell input text`
- `FAST`: paste nguyên câu qua Base64 (giống `send_text_fast`)
- `BALANCED`: gõ từng ký tự (giống `send_text_balanced`, fix drift)
- Hỗ trợ WiFi ADB: điền IP:Port trong cài đặt

### Accessibility Mode  
- Paste text vào focused input field không cần ADB
- Intercept Vol+/Vol- để bắt/dừng (không hiện volume bar)

### Volume Key Control
- Cần bật Accessibility Service
- Vol+ → Bắt đầu gõ
- Vol- → Dừng

---

## Key System

- Kết nối `key.py` server (Flask)
- Key được cache trong `EncryptedSharedPreferences` (AES-256)
- Heartbeat check `/check_kill` mỗi 5 phút qua WorkManager
- Rate limiter: 5 lần sai → khoá 10 phút
- HWID = SHA-256(Android ID + manufacturer + model + serial)

---

## Ghi chú

- `local.properties` **không commit** lên git (đã có trong `.gitignore` mặc định)
- Build release: `./gradlew assembleRelease` (cần ký APK)
- Nếu server dùng HTTP (không HTTPS), `network_security_config.xml` đã cho phép `cleartext`
